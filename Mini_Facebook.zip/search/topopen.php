<?php
//$p = $_GET['pic'];
//echo $_GET['pic'];
echo "dfgdGF";
?>